COURT CLASH

Open index.html in a modern browser to play, or serve this folder with any static web host. No build step or dependencies are required.

WASD: move. Mouse or drag: aim. Hold click or F: throw. E: catch. Space: dash. V: switch view. P: pause.

Hosting status: not deployed. ChatGPT Sites is currently disabled by the workspace administrator.
